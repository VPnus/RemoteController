#ifndef MYBUTTON_H
#define MYBUTTON_H


class Mybutton
{
public:
    Mybutton();
};

#endif // MYBUTTON_H
