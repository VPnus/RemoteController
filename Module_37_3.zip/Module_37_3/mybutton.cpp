#include "mybutton.h"

Mybutton::Mybutton()
{

}
